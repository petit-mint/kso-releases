# KSO パイロット版 配布パッケージ

このパッケージには、KSOのインストーラー、2種類の手順書、0.4.0からの変更履歴が含まれています。

## はじめに

1. ZIPファイル全体を展開します。
2. [インストール手順書](./installation-guide/kso-installation-guide-pilot.md)を開きます。
3. 手順書に従い、[KSOインストーラー](./installer/KSO_Pilot_0.5.0_x64-setup.exe)を実行します。
4. インストール後は、[操作手順書](./operation-guide/kso-operation-guide-pilot.md)を参照します。
5. 0.4.0からの変更点は、[0.5.0変更履歴](./release-notes/KSO_Pilot_0.5.0.md)を参照します。

## 内容

```text
KSO_Pilot_0.5.0_Distribution/
├─ README.md
├─ はじめにお読みください.txt
├─ installer/
│  ├─ KSO_Pilot_0.5.0_x64-setup.exe
│  └─ KSO_Pilot_0.5.0_x64-setup.exe.sha256
├─ installation-guide/
│  ├─ kso-installation-guide-pilot.md
│  └─ images/
├─ operation-guide/
   ├─ kso-operation-guide-pilot.md
   └─ images/
└─ release-notes/
   └─ KSO_Pilot_0.5.0.md
```

Markdown手順書の画像は、それぞれの `images` フォルダーへの相対リンクです。フォルダー構成を変えず、ZIP全体を展開してから閲覧してください。
