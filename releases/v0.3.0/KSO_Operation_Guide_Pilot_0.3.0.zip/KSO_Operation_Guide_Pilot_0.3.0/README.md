# KSO 操作手順書

パイロット版の操作手順書は、次のファイルを参照してください。

- [KSO 操作手順書 パイロット版](./kso-operation-guide-pilot.md)

画面画像は `images` フォルダーに格納しています。
